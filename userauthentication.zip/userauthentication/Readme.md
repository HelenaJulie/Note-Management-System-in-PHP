How to test:
I have used AMPPS server to run and test my application.
Steps:
1. Download AMPPS PHP Dev Package from the link: https://ampps.com/download
2. Install and open AMPPS. Click on the home icon in AMPPS. This will lead you to its home page in browser. Navigate to Add Domain. Add the project name. My project runs in the name userauthentication (Note: important to keep the same name for the domain name).
3. Download the zip file from the git hub link:
Extract and copy all the folders and files inside the folder “userauthentication”.
4. Go to C:\Program Files (x86)\Ampps. In this there will be a folder in name www. Inside the folder there will be a folder with our domain name “userauthentication”.  In that folder paste all the copied folders and files in step 3.
5. Click on the home icon in AMPPS. This will lead you to its home page in browser. Navigate to myPhpAdmin. Add Database c1. Create tables “users” and “notes” using below SQL statements:
CREATE TABLE `users` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
);



CREATE TABLE `notes` (
  `note_id` bigint(64) NOT NULL AUTO_INCREMENT,  
  `id` bigint(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` varchar(255) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`note_id`),
    FOREIGN KEY (`id`) REFERENCES users(`id`)
);

Since the password is hashed. Do not add new records in ‘users’ using SQL.
Add it using my application.

6. To run my application, in browser enter http://localhost/userauthentication/
7. To add a user in users table use the Register button in the application.
