<?php
class Bootstrap{
    private $request;
    private $controller;
    private $action;
    public function __construct($request){
        $this->request=$request;
        //if there is no controller in the url.. make it home
        if($this->request['controller']==''){
            $this->controller='Home';
        } else{
            $this->controller=$this->request['controller'];
        }
        //if there is no action in url... make it index
        if($this->request['action']==''){
            $this->action='Index';
        } else{
            $this->action=$this->request['action'];
        }
        
    }
    public function createController(){
        if(class_exists($this->controller)){
            $parents=class_parents($this->controller);
            if(in_array("Controller",$parents)){
                if(method_exists($this->controller,$this->action)){
                    return new $this->controller($this->action,$this->request);
                } else{
                    echo '<h1>Method does not exist</h1>';
                    return;
                }
            } else{
                echo '<h1>Base controller does not exist</h1>';
                return;
                
            }
        } else{
            echo '<h1>Controller class does not exist</h1>';
            return;
                
        }
    }
}