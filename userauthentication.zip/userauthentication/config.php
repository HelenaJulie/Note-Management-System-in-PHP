<?php
//database related constants
define("HOSTNAME", "localhost");
define("USERNAME", "root");
define("USER_PASSWORD", "mysql");
define("DATABASENAME", "c1");

define("ROOT_PATH","/userauthentication/");
define("ROOT_URL","http://localhost/userauthentication/");