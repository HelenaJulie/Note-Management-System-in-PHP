<?php

class Home extends Controller{
    protected function Index(){
       /* if(isset($_SESSION['id']){
			$viewmodel = new NotesModel();
			$this->returnView($viewmodel->Index(), true);
		} else{
			$viewmodel = new HomeModel();
			$this->returnView($viewmodel->Index(), true);
		}
*/

		$viewmodel = new HomeModel();
		$this->returnView($viewmodel->Index(), true);
    }
}