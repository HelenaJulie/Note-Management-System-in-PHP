<?php

class Notes extends Controller{
    protected function Index(){
        $viewmodel=new NotesModel();
        $this->returnView($viewmodel->Index(),true);
        
    }
    protected function add(){
		$viewmodel = new NotesModel();
		$this->returnView($viewmodel->add(), true);
    }
    protected function edit(){
		$viewmodel = new NotesModel();
		$this->returnView($viewmodel->edit(), true);
    }
    protected function delete(){
		$viewmodel = new NotesModel();
		$viewmodel->delete();
	}
}