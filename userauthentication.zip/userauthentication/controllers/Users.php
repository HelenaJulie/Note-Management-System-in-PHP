<?php

class Users extends Controller{
   /* protected function Index(){
		if(isset($_SESSION['id']){
			$viewmodel = new NotesModel();
			$this->returnView($viewmodel->Index(), true);
		} else{
			$viewmodel = new HomeModel();
			$this->returnView($viewmodel->Index(), true);
		}
		
	}*/
	
	protected function register(){
		$viewmodel = new UsersModel();
		$this->returnView($viewmodel->register(), true);
	}

	protected function login(){
		$viewmodel = new UsersModel();
		$this->returnView($viewmodel->login(), true);
	}

	protected function logout(){
		unset($_SESSION['is_logged_in']);
		unset($_SESSION['id']);
		unset($_SESSION['name']);
		unset($_SESSION['email']);
		session_destroy();
		// Redirect
		header('Location: '.ROOT_URL);
}
}