<?php

class NotesModel extends Model{
   
        public function Index(){
            $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            if($post['submitDelete']){
                // Insert into MySQL
                
                $this->query('DELETE FROM notes WHERE note_id= :note_id');
                $this->bind(':note_id', $post['note_id']);
                $this->execute();
                header('Location: '.ROOT_URL.'Notes/Index');
            
        }
        if($post['submitEdit']){
            $_SESSION['note_id']=$post['note_id'];
            $_SESSION['title']=$post['title'];
            $_SESSION['body']=$post['body'];
            header('Location: '.ROOT_URL.'Notes/edit');
            
        }

        if(isset($_SESSION['id'])){
            $id =$_SESSION['id'];
            
            $this->query('SELECT * FROM notes WHERE id=:id');
            $this->bind(':id', $id);
            $rows = $this->resultSet();
            
            
            return $rows;
            } else {
                echo 'Please Login!!';
                
            }
            
        return;
        }
    
        public function add(){
            // Sanitize POST
            $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $id =$_SESSION['id'];
            $name =$_SESSION['name'];
            if($post['submit']){
                // Insert into MySQL
                $this->query('INSERT INTO notes (id, name, title, body) VALUES(:id, :username, :title, :body)');
                
                $this->bind(':id', $id);
                $this->bind(':username', $name);
                $this->bind(':title', $post['title']);
                $this->bind(':body', $post['body']);
                
                $this->execute();
                header('Location: '.ROOT_URL.'Notes');
                
            }
            return;
        }
        public function edit(){
            // Sanitize POST
            $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
    
            if($post['submit']){
                // Insert into MySQL
                $this->query('UPDATE notes SET title=:title, body=:body WHERE note_id=:note_id');
                $this->bind(':note_id', $post['note_id']);
                $this->bind(':title', $post['title']);
                $this->bind(':body', $post['body']);
                $this->execute();
                header('Location: '.ROOT_URL.'Notes');
               }
            return;
        }
        
}