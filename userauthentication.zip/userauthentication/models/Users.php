<?php

class UsersModel extends Model{
  public function register(){
		// Sanitize POST
		$post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

		if($post['username']=='' || $post['email']=='' || $post['userpassword'=='']){
			echo 'Fill All Fields to Register.';
		}

		

		if($post['submit']){
			$this->query('SELECT * FROM users WHERE email = :email');
			$this->bind(':email', $post['email']);
			
			
			$row = $this->single();
			if(isset($row['id'])){

				// Redirect
				echo 'User with same email id aalready exists';
				return;
				
			} else{
				
			
			$password = password_hash($post['userpassword'], PASSWORD_DEFAULT);
		
			
			// Insert into MySQL
			$this->query('INSERT INTO users (name, email, password, updated_at) VALUES (:username, :email, :userpassword, :updated_at)');
			$updated_at='';
            $this->bind(':username', $post['username']);
			$this->bind(':email', $post['email']);
			$this->bind(':userpassword', $password);
			$this->bind(':updated_at', $updated_at);
			
                
			$this->execute();
			// Verify
			
			$this->query('SELECT * FROM users WHERE email = :email AND password = :userpassword');
			$this->bind(':email', $post['email']);
			$this->bind(':userpassword', $password);
			
			$row = $this->single();
			
			if(isset($row['id'])){

				// Redirect
				header('Location: '.ROOT_URL.'Users/login');
				
			} else{
				echo 'Wrong inputs';
			}
		}
		}
		return;
	}

	public function login(){
		// Sanitize POST
		$post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

		
		if($post['submit']){
			$password = password_hash($post['userpassword'], PASSWORD_DEFAULT);
		// Compare Login
			$this->query('SELECT * FROM users WHERE email = :email');
			$this->bind(':email', $post['email']);
			
			
			$row = $this->single();
			
			if (password_verify($post['userpassword'],$row['password'])){
				$_SESSION['is_logged_in'] = true;
				$_SESSION['id'] = $row['id'];
				$_SESSION['name'] = $row['name'];
				$_SESSION['email'] = $row['email'];
			
				header('Location: '.ROOT_URL.'Notes');
			} else {
				
				echo 'Incorrect email or passowrd.';
			}
		}
		return;
	}
}