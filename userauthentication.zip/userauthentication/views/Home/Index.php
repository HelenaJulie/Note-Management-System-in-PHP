<div class="text-center">
	<h1>Note Management System</h1>
	<?php if(isset($_SESSION['is_logged_in'])) : ?>
    <a class="btn btn-primary text-center" href="<?php echo ROOT_URL;?>Notes">Notes</a>
      <?php else : ?>
	  <p class="lead">User's can login to add and maintain notes.</p>
          <?php endif; ?>
	</div>