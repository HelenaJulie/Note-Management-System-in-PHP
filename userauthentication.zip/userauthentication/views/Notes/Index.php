<div>

	<h1>User's Notes</h1>
	
    <?php if(isset($_SESSION['is_logged_in'])) : ?>
	<?php foreach($viewmodel as $eachnote): ?>
		<div class="well">
			<h3><?php echo $eachnote['title']; ?></h3>
			<small><?php echo $eachnote['name']."   ". $eachnote['created_at']; ?></small>
			<hr />
			<p><?php echo $eachnote['body']; ?></p>
			<br />
			
    
			<form method="post" action="<?php $_SERVER["PHP_SELF"]; ?>">
			<input type="hidden" name="note_id" value="<?php echo $eachnote['note_id']; ?>"/>
			<input type="hidden" name="title" value="<?php echo $eachnote['title']; ?>"/>
			<input type="hidden" name="body" value="<?php echo $eachnote['body']; ?>"/>
			<input class="btn btn-secondary" name="submitEdit" type="submit" value="Edit"/>
			<input class="btn btn-secondary" name="submitDelete" type="submit" value="Delete"/>
			</form>
			</div>
	<?php endforeach; ?>
	<?php unset($eachnote); ?>
    <?php endif; ?>
	
	
	
</div>