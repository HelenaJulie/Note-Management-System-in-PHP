<div class="panel panel-default">
  <div class="panel-heading">
	<?php if(isset($_SESSION['is_logged_in'])) : ?>
	
    <h3 class="panel-title">Add New Notes Here:</h3>
  </div>
  <div class="panel-body">
    <form method="post" action="<?php $_SERVER["PHP_SELF"] ?>">
    	<div class="form-group">
    		<label>Notes Title</label>
    		<input type="text" name="title" class="form-control" />
    	</div>
    	<div class="form-group">
    		<label>Notes Body</label>
    		<textarea name="body" class="form-control"></textarea>
    	</div>
    	<input class="btn btn-primary" name="submit" type="submit" value="Submit" />
      </form>
<?php else:?>
<h3 class="panel-title">Please login.</h3>

<?php endif; ?>
  </div>
</div>