<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Delete Note</h3>
  </div>
  <div class="panel-body">
    <form method="post" action="<?php $_SERVER["PHP_SELF"] ?>">
    <input type="hidden" name="note_id" name="note_id" value="<?php echo $_GET['note_id']; ?>"/>
    	<?php echo "Notes Title:".$_GET['title'];?>
        <?php echo "Notes Body:".$_GET['body'];?>
        
    	<input class="btn btn-primary" name="submit" type="submit" value="Submit" />
        
    </form>
  </div>
</div>