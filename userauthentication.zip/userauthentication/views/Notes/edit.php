<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Edit Note</h3>
  </div>
  <div class="panel-body">
    <form method="post" action="<?php $_SERVER["PHP_SELF"] ?>">
    <input type="hidden" name="note_id" name="note_id" value="<?php echo $_SESSION['note_id']; ?>"/>
    	<div class="form-group">
    		<label>Notes Title</label>
    		<input type="text" name="title" value="<?php echo $_SESSION['title'];?>" class="form-control" />
    	</div>
    	<div class="form-group">
    		<label>Notes Body</label>
				<input type="text" name="body" value="<?php echo $_SESSION['body'];?>" class="form-control" />
    		</div>

    	<input class="btn btn-primary" name="submit" type="submit" value="Submit" />
        
    </form>
  </div>
</div>