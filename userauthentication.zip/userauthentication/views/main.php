<html>
<head>
	<title>User's Notes</title>
	<link rel="stylesheet" href="<?php echo ROOT_PATH; ?>styles/css/bootstrap.css">
	<link rel="stylesheet" href="<?php echo ROOT_PATH; ?>styles/css/style.css">
</head>
<body>  
<br/>
<br/>

<div class="container">
    <?php if(isset($_SESSION['is_logged_in'])) : ?>
    <a class="btn btn-primary text-center" href="<?php echo ROOT_URL;?>Notes/add">+Notes</a>
 <a class="btn btn-primary text-center" href="<?php echo ROOT_URL;?>Users/logout">Logout</a>
          <?php else : ?>
          <a class="btn btn-primary text-center" href="<?php echo ROOT_URL;?>Users/login">Login</a>
          <a class="btn btn-primary text-center" href="<?php echo ROOT_URL;?>Users/register">Register</a>
          <?php endif; ?>
          </div> 
    <div class="container">
    
     <div class="row">
     <br/>
     
     <br/>
     	<?php require($view); ?>
     </div>

    </div>
</body>
</html>


